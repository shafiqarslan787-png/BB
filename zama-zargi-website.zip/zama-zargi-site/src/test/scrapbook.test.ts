import { describe, expect, it } from "vitest";
import { keepScrapbookEntry } from "@/lib/scrapbook";

describe("Scrapbook exclusions", () => {
  it("removes the shared-photo prompt from saved scrapbook entries", () => {
    expect(keepScrapbookEntry({ title: "[A Photo of Us]" })).toBe(false);
    expect(keepScrapbookEntry({ title: "[Our Favorite Memory]" })).toBe(true);
  });

  it("removes the appreciation prompt while preserving other memories", () => {
    expect(keepScrapbookEntry({ title: "[Something I Appreciate About Amy]" })).toBe(false);
    expect(keepScrapbookEntry({ title: "[Something I Appreciated About Amy]" })).toBe(false);
    expect(keepScrapbookEntry({ title: "[An Inside Joke]" })).toBe(true);
  });
});