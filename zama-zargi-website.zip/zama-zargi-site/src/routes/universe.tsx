import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CONFIG, pick } from "@/config";
import { Doodles, Heading, Meme, NextButton, Page, SectionTitle } from "@/components/scrap";

export const Route = createFileRoute("/universe")({
  head: () => ({
    meta: [
      { title: "The Universe Is Weird — Zama Zargi" },
      { name: "description", content: "An extremely unserious field guide to the universe, made for Amy." },
      { property: "og:title", content: "The Universe Is Weird — Zama Zargi" },
      { property: "og:description", content: "An extremely unserious field guide to the universe." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Universe,
});

const FACTS = [
  { name: "Stars", art: <Star />, fact: "Stars shine by nuclear fusion, turning hydrogen into helium in their cores.", note: "giant balls of plasma casually carrying the aesthetic of the entire sky.", more: "Our Sun is a fairly average star. Its light takes about 8 minutes 20 seconds to reach Earth, so you always see it slightly in the past." },
  { name: "Galaxies", art: <Galaxy />, fact: "The Milky Way contains roughly 100–400 billion stars.", note: "the universe really said: what if we put billions of stars in one place.", more: "The nearest large galaxy, Andromeda, is about 2.5 million light-years away and is heading toward us. They'll merge in roughly 4–5 billion years." },
  { name: "Nebulae", art: <Nebula />, fact: "Nebulae are huge clouds of gas and dust, and many are where new stars are born.", note: "cosmic clouds with absolutely unreasonable visual effects.", more: "The Orion Nebula is about 1,300 light-years away and is visible to the naked eye as a fuzzy patch in Orion's sword." },
  { name: "Black holes", art: <BlackHole />, fact: "A black hole's gravity is so strong that not even light can escape past its event horizon.", note: "space's most terrifying ‘do not enter’ sign.", more: "In 2019 the Event Horizon Telescope captured the first image of a black hole's shadow, in the galaxy M87." },
  { name: "Neutron stars", art: <Neutron />, fact: "A neutron star packs more mass than the Sun into a ball about 20 km across.", note: "a teaspoon of this weighs more than a mountain. rude.", more: "Some neutron stars, called pulsars, spin hundreds of times per second and sweep beams of radio waves across space like lighthouses." },
  { name: "The observable universe", art: <Observable />, fact: "The observable universe is about 93 billion light-years across.", note: "and we still can't find the TV remote.", more: "It's larger than 13.8 billion light-years (the universe's age) because space itself has expanded while light was travelling to us." },
];

function Universe() {
  const [open, setOpen] = useState<number | null>(null);
  const [thought, setThought] = useState<string | null>(null);
  const [n, setN] = useState(0);
  return (
    <Page>
      <section className="relative">
        <Doodles count={16} seed={3} />
        <Heading title="SPACE IS HUGE AND WE ARE ALL JUST VIBRATING." sub="An extremely unserious field guide to the universe." />
      </section>

      <SectionTitle note="facts are real, annotations are not">Space facts for the cosmically curious</SectionTitle>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {FACTS.map((f, i) => (
          <article key={f.name} className="relative notebook scrap-card p-5" style={{ transform: `rotate(${(i % 3) - 1}deg)` }}>
            <span className="tape -top-3 left-6 -rotate-6" />
            <div className="mx-auto h-28 w-28">{f.art}</div>
            <h3 className="mt-2 text-xl font-bold">{f.name}</h3>
            <p className="mt-1 text-sm leading-6">{f.fact}</p>
            <p className="mt-2 font-hand text-xl text-ink/80">↳ “{f.note}”</p>
            <button onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i} className="mt-3 text-sm font-display font-semibold underline decoration-dashed underline-offset-4">
              {open === i ? "close notes ↑" : "tell me more ↓"}
            </button>
            {open === i && <p className="pop-in mt-2 rounded-lg bg-butter/60 p-3 text-sm leading-6">{f.more}</p>}
          </article>
        ))}
      </div>

      <SectionTitle note="a documentary">{CONFIG.name} at 3 AM</SectionTitle>
      <div className="grid items-center gap-6 md:grid-cols-[2fr_1fr]">
        <div className="grid gap-4 sm:grid-cols-2">
          {CONFIG.threeAm.map((c, i) => (
            <div key={i} className="scrap-card bg-sky/30 p-4">
              <p className="font-display text-xs font-bold tracking-widest">PANEL {i + 1} · {["11:58 PM", "1:12 AM", "3:03 AM", "4:17 AM"][i]}</p>
              <p className="mt-2 font-hand text-2xl leading-tight">{c}</p>
            </div>
          ))}
        </div>
        <Meme kind="sleepy" caption={CONFIG.captions.spaceSleepy} size={200} rotate={3} />
      </div>

      <SectionTitle>Cosmic nonsense generator</SectionTitle>
      <div className="scrap-card relative mx-auto max-w-2xl bg-lavender/30 p-8 text-center">
        <Meme kind="heart" size={90} rotate={-10} className="absolute -right-4 -top-10 hidden sm:flex" />
        <button className="btn-scrap" onClick={() => { setThought((t) => pick(CONFIG.spaceThoughts, t ?? undefined)); setN((x) => x + 1); }}>
          GENERATE A QUESTIONABLE SPACE THOUGHT
        </button>
        <p key={n} aria-live="polite" className={`mt-6 min-h-16 font-hand text-3xl ${thought ? "pop-in" : "text-muted-foreground"}`}>
          {thought ?? "(the void is waiting…)"}
        </p>
      </div>

      <NextButton to="/cats">ENOUGH SPACE FOR NOW. RELEASE THE CATS →</NextButton>
    </Page>
  );
}

const S = { stroke: "var(--ink)", strokeWidth: 2.5, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
function Star() { return <svg viewBox="0 0 100 100" aria-hidden><circle cx="50" cy="50" r="22" {...S} fill="var(--butter)" /><path d="M50 12v12M50 76v12M12 50h12M76 50h12M23 23l8 8M69 69l8 8M77 23l-8 8M31 69l-8 8" fill="none" {...S} /></svg>; }
function Galaxy() { return <svg viewBox="0 0 100 100" aria-hidden><path d="M50 50c0-8 12-10 16-2s-4 22-18 22-24-14-22-28 18-26 34-24 28 14 26 30" fill="none" {...S} /><circle cx="50" cy="50" r="5" fill="var(--lavender)" stroke="var(--ink)" strokeWidth={2} /><path d="M20 20l2 4M82 80l2 3M80 22l1 3" fill="none" {...S} /></svg>; }
function Nebula() { return <svg viewBox="0 0 100 100" aria-hidden><path d="M20 60c-8-14 6-28 18-22 4-14 26-16 30-2 14-4 22 12 14 22 6 12-8 22-18 16-8 10-26 8-28-2-12 2-20-6-16-12z" {...S} fill="var(--rose)" fillOpacity={0.6} /><circle cx="52" cy="52" r="3" fill="var(--butter)" stroke="var(--ink)" /></svg>; }
function BlackHole() { return <svg viewBox="0 0 100 100" aria-hidden><ellipse cx="50" cy="50" rx="42" ry="14" {...S} fill="var(--butter)" fillOpacity={0.7} /><circle cx="50" cy="50" r="18" fill="var(--ink)" stroke="var(--ink)" /><text x="50" y="90" textAnchor="middle" fontFamily="Caveat" fontSize="14" fill="var(--ink)">do not enter</text></svg>; }
function Neutron() { return <svg viewBox="0 0 100 100" aria-hidden><path d="M50 50L20 8M50 50l30 84" stroke="var(--sky)" strokeWidth={8} strokeLinecap="round" /><circle cx="50" cy="50" r="12" {...S} fill="var(--sky)" /></svg>; }
function Observable() { return <svg viewBox="0 0 100 100" aria-hidden><circle cx="50" cy="50" r="40" {...S} fill="var(--sky)" fillOpacity={0.35} />{[[30, 30], [62, 28], [70, 60], [38, 66], [50, 46], [24, 52]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="2.5" fill="var(--ink)" />)}<text x="50" y="54" textAnchor="middle" fontFamily="Caveat" fontSize="11" fill="var(--ink)">you are here-ish</text></svg>; }
